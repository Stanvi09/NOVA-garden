import React, { useEffect, useState } from "react";
import { fetchGarden, GardenView } from "../api/gardenApi";
import GardenCanvas from "../garden/GardenCanvas";
import { Link, useSearchParams } from "react-router-dom";
import { listIssues, Issue } from "../api/issueApi";
import * as intelligence from "../api/intelligenceApi";
import { exportProjectAnalysis, fetchProjects, ProjectItem } from "../api/plantApi";
import PlantProjectModal from "../components/PlantProjectModal";

export default function GardenPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialProjectId = searchParams.get("projectId");

  const [activeProjectId, setActiveProjectId] = useState<string | null>(initialProjectId);
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [garden, setGarden] = useState<GardenView | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [insights, setInsights] = useState<any>({});
  const [notices, setNotices] = useState<any[]>([]);
  const [selectedSeverity, setSelectedSeverity] = useState<string>("ALL");
  const [selectedStatus, setSelectedStatus] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [isPlantModalOpen, setIsPlantModalOpen] = useState(false);

  async function load(targetProjectId = activeProjectId) {
    if (!targetProjectId) {
      setGarden(null);
      setIssues([]);
      setInsights({});
      setNotices([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    try {
      // Fetch available projects
      const projectList = await fetchProjects().catch(() => []);
      setProjects(projectList);

      const data = await fetchGarden(targetProjectId);
      setGarden(data);

      const [issueRows, health, risk, season, notifs, analytics] = await Promise.all([
        listIssues(targetProjectId),
        intelligence.health(targetProjectId).catch(() => null),
        intelligence.risk(targetProjectId).catch(() => null),
        intelligence.season(targetProjectId).catch(() => null),
        intelligence.notifications(targetProjectId).catch(() => []),
        intelligence.analytics(targetProjectId).catch(() => null),
      ]);
      setIssues(issueRows);
      setNotices(notifs || []);
      setInsights({ health, risk, season, analytics });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load garden");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load(activeProjectId);
  }, [activeProjectId]);

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  }, []);

  function handleSelectProject(projectId: string) {
    setActiveProjectId(projectId);
    setSearchParams({ projectId });
  }

  function handlePlantAnotherProject() {
    setError(null);
    setIsPlantModalOpen(true);
  }

  async function handleMarkRead(id: string) {
    if (!activeProjectId) return;
    try {
      await intelligence.readNotification(activeProjectId, id);
      setNotices((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
    } catch (err) {
      console.error("Failed to mark notification read", err);
    }
  }

  const unreadNotices = notices.filter((n) => !n.read);
  const availableStatuses = Array.from(new Set(issues.map((i) => i.status))).sort();
  const normalizedQuery = searchQuery.trim().toLowerCase();
  const filteredIssues = issues.filter((i) => {
    const matchesSeverity = selectedSeverity === "ALL" || i.severity === selectedSeverity;
    const matchesStatus = selectedStatus === "ALL" || i.status === selectedStatus;
    const matchesQuery = normalizedQuery === "" || i.title.toLowerCase().includes(normalizedQuery);
    return matchesSeverity && matchesStatus && matchesQuery;
  });
  const hasProject = Boolean(garden);

  async function handleExport() {
    if (!activeProjectId || !garden) return;
    const exportBlob = await exportProjectAnalysis(activeProjectId);
    const downloadUrl = URL.createObjectURL(exportBlob);
    const link = document.createElement("a");
    link.href = downloadUrl;
    link.download = `${garden.projectName.replace(/[^a-z0-9]+/gi, "-").toLowerCase() || "nova-garden"}-analysis.json`;
    link.click();
    URL.revokeObjectURL(downloadUrl);
  }

  return (
    <div style={{ minHeight: "100vh", background: "transparent", padding: "32px 40px" }}>
      <header
        style={{
          position: "relative",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: 24,
          flexWrap: "wrap",
          gap: 16,
        }}
      >
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <Link to="/" style={{ textDecoration: "none" }}>
              <h1 style={{ fontSize: 28, margin: 0, color: "var(--color-forest)" }}><span style={{ fontFamily: "var(--font-mono)", fontSize: "0.75em", fontWeight: 700 }}>NOVA</span> garden</h1>
            </Link>
            <span
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: 11,
                padding: "3px 8px",
                background: "var(--color-sage-soft)",
                borderRadius: 12,
                color: "var(--color-forest)",
              }}
            >
              Living Ecosystem
            </span>

            {/* Project Switcher Dropdown */}
            {projects.length > 0 && (
              <div style={{ marginLeft: 6 }}>
                <select
                  value={activeProjectId ?? ""}
                  onChange={(e) => handleSelectProject(e.target.value)}
                  style={{
                    padding: "6px 12px",
                    borderRadius: 8,
                    border: "1px solid var(--color-sage-soft)",
                    background: "var(--color-surface)",
                    fontSize: 13,
                    fontFamily: "var(--font-body)",
                    color: "var(--color-forest)",
                    fontWeight: 600,
                    cursor: "pointer",
                  }}
                >
                  {projects.map((p) => (
                    <option key={p.id} value={p.id}>
                      🌿 {p.name} ({p.moduleCount} modules, {p.openIssueCount} open)
                    </option>
                  ))}
                  {!projects.some((p) => p.id === activeProjectId) && (
                    <option value={activeProjectId ?? ""}>🌿 {garden?.projectName || activeProjectId}</option>
                  )}
                </select>
              </div>
            )}
          </div>
          <p style={{ margin: "4px 0 0", fontSize: 13, color: "var(--color-muted)" }}>
            The living state of your codebase — grown from live issue data and dependency trees.
          </p>
        </div>

        <div style={{ display: "flex", gap: 10, alignItems: "center", marginLeft: "auto" }}>
          {garden && (
            <>
              <button
                onClick={() => load(activeProjectId)}
                style={{ padding: "8px 14px", borderRadius: 8, border: "1px solid var(--color-sage-soft)", background: "var(--color-surface)", fontSize: 13, fontFamily: "var(--font-body)", cursor: "pointer" }}
              >
                Refresh
              </button>
              <button
                onClick={handlePlantAnotherProject}
                style={{ padding: "8px 14px", borderRadius: 8, border: "1px solid var(--color-sage-soft)", background: "var(--color-surface)", fontSize: 13, fontFamily: "var(--font-body)", cursor: "pointer" }}
              >
                Plant Another Project
              </button>
              <button
                onClick={() => handleExport().catch((err) => setError(err instanceof Error ? err.message : "Failed to export analysis"))}
                style={{ padding: "8px 14px", borderRadius: 8, border: "none", background: "var(--color-charcoal)", color: "var(--color-ivory)", fontSize: 13, fontFamily: "var(--font-body)", cursor: "pointer" }}
              >
                Export Dashboard
              </button>
            </>
          )}
        </div>
      </header>

      {/* Plant a New Project Modal */}
      <PlantProjectModal
        isOpen={isPlantModalOpen}
        onClose={() => setIsPlantModalOpen(false)}
        onPlantComplete={(newProjectId) => {
          handleSelectProject(newProjectId);
        }}
      />

      {loading && !garden && <p style={{ color: "var(--color-olive)" }}>Tending garden & computing signals…</p>}
      {error && (
        <div
          style={{
            padding: 16,
            background: "var(--color-blossom-bg)",
            border: "1px solid var(--color-coral)",
            borderRadius: 8,
            marginBottom: 20,
            color: "var(--color-coral)",
          }}
        >
          {error}. Ensure the backend is running on http://localhost:4000.
        </div>
      )}

      <GardenCanvas garden={garden} onPlantProject={() => setIsPlantModalOpen(true)} />

      <section style={{ marginTop: 32 }}>
          {/* Top Intelligence Metrics */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
              gap: 16,
            }}
          >
            <div
              style={{
                padding: 18,
                background: "var(--color-surface)",
                borderRadius: 12,
                border: "1px solid var(--color-sage-soft)",
              }}
            >
              <small style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--color-muted)" }}>
                PROJECT HEALTH
              </small>
              <h2 style={{ fontSize: 28, margin: "6px 0 2px", color: "var(--color-forest)" }}>
                {hasProject ? `${insights.health?.healthScore ?? garden?.overallHealth}/100` : "Waiting"}
              </h2>
              <span style={{ fontSize: 12, color: "var(--color-olive)" }}>
                {hasProject ? `${insights.health?.activeBugs ?? 0} active · ${insights.health?.resolvedBugs ?? 0} resolved` : "Plant a project to calculate health"}
              </span>
            </div>

            <div
              style={{
                padding: 18,
                background: "var(--color-surface)",
                borderRadius: 12,
                border: "1px solid var(--color-sage-soft)",
              }}
            >
              <small style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--color-muted)" }}>
                PROJECTED RISK
              </small>
              <h2
                style={{
                  fontSize: 28,
                  margin: "6px 0 2px",
                  color: insights.risk?.riskLevel === "CRITICAL" ? "var(--color-coral)" : "var(--color-forest)",
                }}
              >
                {hasProject ? insights.risk?.riskLevel ?? "Unknown" : "Waiting"}
              </h2>
              <span style={{ fontSize: 12, color: "var(--color-muted-strong)" }}>
                {hasProject ? `Score: ${insights.risk?.riskScore ?? "--"}/100 heuristic` : "Analysis will assess project risk"}
              </span>
            </div>

            <div
              style={{
                padding: 18,
                background: "var(--color-surface)",
                borderRadius: 12,
                border: "1px solid var(--color-sage-soft)",
              }}
            >
              <small style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--color-muted)" }}>
                GARDEN SEASON
              </small>
              <h2 style={{ fontSize: 28, margin: "6px 0 2px", color: "var(--color-forest)" }}>
                {hasProject ? insights.season?.currentSeason ?? "Unknown" : "Waiting"}
              </h2>
              <span style={{ fontSize: 12, color: "var(--color-muted-strong)" }}>
                {hasProject ? insights.season?.reason ?? "Season unavailable" : "Analysis will determine the season"}
              </span>
            </div>

            <div
              style={{
                padding: 18,
                background: "var(--color-surface)",
                borderRadius: 12,
                border: "1px solid var(--color-sage-soft)",
              }}
            >
              <small style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--color-muted)" }}>
                UNREAD SIGNALS
              </small>
              <h2
                style={{
                  fontSize: 28,
                  margin: "6px 0 2px",
                  color: unreadNotices.length > 0 ? "var(--color-coral)" : "var(--color-forest)",
                }}
              >
                {unreadNotices.length}
              </h2>
              <span style={{ fontSize: 12, color: "var(--color-muted-strong)" }}>
                {hasProject ? `${notices.length} total recorded ecosystem notifications` : "Analysis notifications will appear here"}
              </span>
            </div>
          </div>

          {/* Ecosystem Notifications Panel */}
          {hasProject && notices.length > 0 && (
            <div
              style={{
                marginTop: 24,
                padding: 18,
                background: "var(--color-surface)",
                borderRadius: 12,
                border: "1px solid var(--color-sage-soft)",
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                <h3 style={{ fontSize: 16, margin: 0 }}>Ecosystem Notifications & Signals</h3>
                <span style={{ fontSize: 12, color: "var(--color-muted)", fontFamily: "var(--font-mono)" }}>
                  {unreadNotices.length} unread
                </span>
              </div>
              <div style={{ display: "grid", gap: 8 }}>
                {notices.slice(0, 4).map((n) => (
                  <div
                    key={n.id}
                    style={{
                      padding: "10px 14px",
                      borderRadius: 8,
                      background: n.read ? "var(--color-ivory)" : "var(--color-surface)",
                      border: n.read ? "1px solid var(--color-sage-soft)" : "1px solid var(--color-coral)",
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <div>
                      <strong style={{ fontSize: 13, color: n.read ? "var(--color-charcoal)" : "var(--color-coral)" }}>
                        {n.title}
                      </strong>
                      <p style={{ margin: "2px 0 0", fontSize: 12, color: "var(--color-muted-strong)" }}>{n.body}</p>
                    </div>
                    {!n.read && (
                      <button
                        onClick={() => handleMarkRead(n.id)}
                        style={{
                          padding: "4px 10px",
                          fontSize: 11,
                          borderRadius: 6,
                          border: "1px solid var(--color-sage-soft)",
                          background: "var(--color-surface)",
                          color: "var(--color-forest)",
                          cursor: "pointer",
                        }}
                      >
                        Mark read
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {!hasProject && (
            <div style={{ marginTop: 24, padding: 18, background: "var(--color-surface)", borderRadius: 12, border: "1px solid var(--color-sage-soft)" }}>
              <h3 style={{ fontSize: 16, margin: "0 0 6px" }}>Ecosystem Notifications & Signals</h3>
              <p style={{ margin: 0, fontSize: 13, color: "var(--color-muted)" }}>Notifications will appear when Nova Garden has analyzed a submitted project.</p>
            </div>
          )}

          {/* Analytics Snapshot */}
          {hasProject && insights.analytics && (
            <div
              style={{
                marginTop: 24,
                padding: 20,
                background: "var(--color-surface)",
                borderRadius: 12,
                border: "1px solid var(--color-sage-soft)",
              }}
            >
              <h3 style={{ fontSize: 16, marginBottom: 16 }}>Ecosystem Analytics & Workload</h3>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
                  gap: 16,
                }}
              >
                <div>
                  <h4 style={{ fontSize: 12, fontFamily: "var(--font-mono)", color: "var(--color-muted)", margin: "0 0 8px" }}>
                    SEVERITY DISTRIBUTION
                  </h4>
                  <div style={{ display: "grid", gap: 4 }}>
                    {Object.entries(insights.analytics.severityDistribution || {}).map(([sev, count]: any) => (
                      <div key={sev} style={{ display: "flex", justifyContent: "space-between", fontSize: 13 }}>
                        <span style={{ color: sev === "CRITICAL" ? "var(--color-coral)" : "var(--color-muted-strong)" }}>{sev}</span>
                        <strong>{count}</strong>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 style={{ fontSize: 12, fontFamily: "var(--font-mono)", color: "var(--color-muted)", margin: "0 0 8px" }}>
                    DEVELOPER WORKLOAD
                  </h4>
                  <div style={{ display: "grid", gap: 4 }}>
                    {(insights.analytics.developerWorkload || []).slice(0, 5).map(([dev, count]: any) => (
                      <div key={dev} style={{ display: "flex", justifyContent: "space-between", fontSize: 13 }}>
                        <span>{dev}</span>
                        <strong>{count} issues</strong>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 style={{ fontSize: 12, fontFamily: "var(--font-mono)", color: "var(--color-muted)", margin: "0 0 8px" }}>
                    BUG RECURRENCE BY MODULE
                  </h4>
                  <div style={{ display: "grid", gap: 4 }}>
                    {(insights.analytics.bugRecurrence || []).slice(0, 5).map(([mod, count]: any) => (
                      <div key={mod} style={{ display: "flex", justifyContent: "space-between", fontSize: 13 }}>
                        <span>{mod}</span>
                        <strong>{count} total</strong>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {!hasProject && (
            <div style={{ marginTop: 24, padding: 20, background: "var(--color-surface)", borderRadius: 12, border: "1px solid var(--color-sage-soft)" }}>
              <h3 style={{ fontSize: 16, margin: "0 0 6px" }}>Ecosystem Analytics & Workload</h3>
              <p style={{ margin: 0, fontSize: 13, color: "var(--color-muted)" }}>Severity, module recurrence, and workload analytics will populate from your project&apos;s analysis.</p>
            </div>
          )}

          {/* Active Ecosystem Issues */}
          <div style={{ marginTop: 32 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14, flexWrap: "wrap", gap: 12 }}>
              <div>
                <h2 style={{ fontSize: 20, margin: 0 }}>Active Ecosystem Issues</h2>
                <p style={{ margin: "2px 0 0", fontSize: 13, color: "var(--color-muted)" }}>
                  Select an issue to inspect its Bug DNA, Impact Radius, Root Cause, What-If simulation, Autopsy, and Prevention workflow.
                </p>
              </div>
            </div>

            <div
              style={{
                display: "flex",
                gap: 10,
                alignItems: "center",
                flexWrap: "wrap",
                marginBottom: 14,
              }}
            >
              <label style={{ flex: "1 1 220px", minWidth: 180 }}>
                <span style={{ position: "absolute", width: 1, height: 1, overflow: "hidden", clip: "rect(0 0 0 0)" }}>
                  Search issues by title
                </span>
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search issues by title…"
                  aria-label="Search issues by title"
                  style={{
                    width: "100%",
                    padding: "8px 12px",
                    borderRadius: 8,
                    border: "1px solid var(--color-sage-soft)",
                    fontSize: 13,
                    fontFamily: "var(--font-body)",
                    boxSizing: "border-box",
                  }}
                />
              </label>

              <label>
                <span style={{ position: "absolute", width: 1, height: 1, overflow: "hidden", clip: "rect(0 0 0 0)" }}>
                  Filter by status
                </span>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  aria-label="Filter by status"
                  style={{
                    padding: "8px 10px",
                    borderRadius: 8,
                    border: "1px solid var(--color-sage-soft)",
                    background: "var(--color-surface)",
                    fontSize: 13,
                    fontFamily: "var(--font-body)",
                    color: "var(--color-charcoal)",
                    cursor: "pointer",
                  }}
                >
                  <option value="ALL">All statuses</option>
                  {availableStatuses.map((status) => (
                    <option key={status} value={status}>
                      {status}
                    </option>
                  ))}
                </select>
              </label>

              <div role="group" aria-label="Filter by severity" style={{ display: "flex", gap: 6 }}>
                {["ALL", "CRITICAL", "HIGH", "MEDIUM", "LOW"].map((sev) => (
                  <button
                    key={sev}
                    onClick={() => setSelectedSeverity(sev)}
                    aria-pressed={selectedSeverity === sev}
                    style={{
                      padding: "4px 10px",
                      fontSize: 12,
                      borderRadius: 6,
                      border: selectedSeverity === sev ? "1px solid var(--color-forest)" : "1px solid var(--color-sage-soft)",
                      background: selectedSeverity === sev ? "var(--color-forest)" : "var(--color-surface)",
                      color: selectedSeverity === sev ? "var(--color-on-accent)" : "var(--color-charcoal)",
                      cursor: "pointer",
                    }}
                  >
                    {sev}
                  </button>
                ))}
              </div>
            </div>

            <p aria-live="polite" style={{ margin: "0 0 10px", fontSize: 12, color: "var(--color-muted)" }}>
              {hasProject
                ? `Showing ${filteredIssues.length} of ${issues.length} issue${issues.length === 1 ? "" : "s"}`
                : ""}
            </p>

            <div style={{ display: "grid", gap: 10 }}>
              {filteredIssues.map((issue) => (
                <Link
                  key={issue.id}
                  to={`/issues/${issue.id}?projectId=${activeProjectId}`}
                  style={{
                    padding: "14px 18px",
                    background: "var(--color-surface)",
                    borderRadius: 10,
                    color: "inherit",
                    textDecoration: "none",
                    border: "1px solid var(--color-sage-soft)",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    transition: "border-color 0.15s ease",
                  }}
                >
                  <div>
                    <strong style={{ fontSize: 15, color: "var(--color-charcoal)" }}>{issue.title}</strong>
                    <div style={{ display: "flex", gap: 10, marginTop: 4, fontSize: 12, color: "var(--color-muted)" }}>
                      <span>Module: {garden?.modules.find((m) => m.moduleId === issue.moduleId)?.moduleName ?? "Module"}</span>
                      <span>·</span>
                      <span>Priority: {issue.priority}</span>
                    </div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <span
                      style={{
                        padding: "3px 8px",
                        borderRadius: 6,
                        fontSize: 12,
                        fontFamily: "var(--font-mono)",
                        background:
                          issue.severity === "CRITICAL"
                            ? "var(--color-blossom-bg)"
                            : issue.severity === "HIGH"
                            ? "var(--color-gold-bg)"
                            : "var(--color-ivory-deep)",
                        color: issue.severity === "CRITICAL" ? "var(--color-coral)" : "var(--color-charcoal)",
                      }}
                    >
                      {issue.severity}
                    </span>
                    <span
                      style={{
                        marginLeft: 8,
                        padding: "3px 8px",
                        borderRadius: 6,
                        fontSize: 12,
                        fontFamily: "var(--font-mono)",
                        background:
                          issue.status === "RESOLVED" || issue.status === "PREVENTED"
                            ? "var(--color-teal-bg)"
                            : "var(--color-ivory)",
                        color:
                          issue.status === "RESOLVED" || issue.status === "PREVENTED"
                            ? "var(--color-forest)"
                            : "var(--color-charcoal)",
                      }}
                    >
                      {issue.status}
                    </span>
                  </div>
                </Link>
              ))}
              {filteredIssues.length === 0 && (
                <div style={{ padding: "18px", background: "var(--color-surface)", borderRadius: 10, border: "1px solid var(--color-sage-soft)", color: "var(--color-muted)", fontSize: 13 }}>
                  {!hasProject
                    ? "Detected issues will appear here after you plant a project."
                    : issues.length === 0
                    ? "No issues were detected in this analysis."
                    : "No issues match your current search and filters."}
                </div>
              )}
            </div>
          </div>
      </section>
    </div>
  );
}
