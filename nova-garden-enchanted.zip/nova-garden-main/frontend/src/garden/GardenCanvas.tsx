import React, { useEffect, useMemo, useState } from "react";
import { GardenView, ModuleHealth } from "../api/gardenApi";
import { healthToPlantVisual, layoutModules } from "./gardenLogic";

const WIDTH = 900;
const HEIGHT = 570;
const SOIL_Y = HEIGHT - 140;

const EMPTY_GARDEN_BUGS = [
  { x: 106, y: 108, rotation: -20, color: "coral", scale: 0.8 },
  { x: 238, y: 190, rotation: 34, color: "gold", scale: 0.72 },
  { x: 706, y: 118, rotation: 22, color: "moss", scale: 0.78 },
  { x: 806, y: 250, rotation: -38, color: "slate", scale: 0.7 },
  { x: 122, y: 338, rotation: 30, color: "moss", scale: 0.68 },
  { x: 742, y: 362, rotation: -16, color: "coral", scale: 0.76 },
  { x: 292, y: 388, rotation: -28, color: "gold", scale: 0.64 },
] as const;

interface Props {
  garden: GardenView | null;
  onPlantProject?: () => void;
}

function GardenBug({
  x,
  y,
  rotation,
  color,
  scale,
}: (typeof EMPTY_GARDEN_BUGS)[number]) {
  const shellFill = `url(#garden-bug-${color})`;
  const spotFill = "#f1e6ff";

  return (
    <g transform={`translate(${x} ${y}) rotate(${rotation}) scale(${scale})`} opacity={0.92} aria-hidden="true">
      <path d="M -10 -3 L -19 -10 M -10 3 L -19 10 M 10 -3 L 19 -10 M 10 3 L 19 10" stroke="#4a2f78" strokeWidth={2.2} strokeLinecap="round" />
      <path d="M 10 -4 Q 17 -14 24 -12 M 10 4 Q 17 14 24 12" fill="none" stroke="#4a2f78" strokeWidth={1.8} strokeLinecap="round" />
      <ellipse cx={-5} cy={0} rx={15} ry={12} fill={shellFill} stroke="#2a1c4d" strokeWidth={2.4} />
      <path d="M -5 -10 Q -1 0 -5 10" fill="none" stroke="rgba(241, 230, 255, 0.4)" strokeWidth={1.5} />
      <circle cx={-10} cy={-4} r={2.3} fill={spotFill} opacity={0.85} />
      <circle cx={-2} cy={5} r={2.1} fill={spotFill} opacity={0.85} />
      <circle cx={1} cy={-5} r={1.8} fill={spotFill} opacity={0.85} />
      <ellipse cx={12} cy={0} rx={7} ry={8} fill="#6b4fa0" stroke="#2a1c4d" strokeWidth={2.2} />
      <circle cx={14} cy={-3} r={1.6} fill="#fff3d0" />
      <path d="M 16 -6 Q 20 -15 26 -14 M 16 6 Q 20 15 26 14" fill="none" stroke="#4a2f78" strokeWidth={1.6} strokeLinecap="round" />
    </g>
  );
}

function Plant({
  x,
  y,
  health,
  selected,
  middlePlant,
  onSelect,
}: {
  x: number;
  y: number;
  health: ModuleHealth;
  selected: boolean;
  middlePlant: boolean;
  onSelect: () => void;
}) {
  const visual = healthToPlantVisual(health);
  const plantStemColor = "var(--color-forest)";
  const stemHeight = 60 + visual.heightRatio * 80;
  const moduleNameWords = health.moduleName.split(/\s+/);
  const availableStemHeight = Math.abs(SOIL_Y - y);
  const fullLeafTierCount = Math.min(3, visual.leafCount, Math.max(2, Math.floor(availableStemHeight / 34) + 1));
  const leafTierCount = middlePlant ? 2 : fullLeafTierCount;

  const leafTiers = Array.from({ length: leafTierCount }).map((_, i) => {
    const t = i / Math.max(1, leafTierCount - 1);
    const leafY = SOIL_Y + (y - SOIL_Y) * (middlePlant ? 0.52 + t * 0.38 : 0.28 + t * 0.62);
    const spread = 26 + t * 8;
    const rotation = visual.wilted ? 28 : 16;
    return (
      <g key={i} opacity={visual.wilted ? 0.65 : 0.95} style={{ filter: visual.wilted ? "none" : "drop-shadow(0 0 5px rgba(255,143,199,0.35))" }}>
        <path d={`M ${x} ${leafY} L ${x - spread + 9} ${leafY - 3}`} stroke={plantStemColor} strokeWidth={2.5} strokeLinecap="round" />
        <path d={`M ${x} ${leafY} L ${x + spread - 9} ${leafY - 3}`} stroke={plantStemColor} strokeWidth={2.5} strokeLinecap="round" />
        <ellipse
          cx={x - spread}
          cy={leafY - 4}
          rx={visual.wilted ? 14 : 19}
          ry={visual.wilted ? 7 : 10}
          fill={visual.leafColor}
          transform={`rotate(${-rotation} ${x - spread} ${leafY - 4})`}
        />
        <ellipse
          cx={x + spread}
          cy={leafY - 4}
          rx={visual.wilted ? 14 : 19}
          ry={visual.wilted ? 7 : 10}
          fill={visual.leafColor}
          transform={`rotate(${rotation} ${x + spread} ${leafY - 4})`}
        />
      </g>
    );
  });

  const weeds = Array.from({ length: visual.weedCount }).map((_, i) => {
    const wx = x - 26 + i * 10;
    return (
      <g key={i} opacity={0.85}>
        <line x1={wx} y1={SOIL_Y} x2={wx + 3} y2={SOIL_Y - 16} stroke="#5a3d78" strokeWidth={2} />
        <circle cx={wx + 3} cy={SOIL_Y - 18} r={3.5} fill="#9b3fae" />
      </g>
    );
  });

  return (
    <g
      role="button"
      tabIndex={0}
      aria-label={`${health.moduleName}: ${health.level.toLowerCase()}, health ${health.healthScore}`}
      onClick={onSelect}
      onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onSelect()}
      style={{ cursor: "pointer" }}
    >
      <path
        d={`M ${x} ${SOIL_Y} Q ${x + (visual.wilted ? 14 : 4)} ${y + stemHeight * 0.4} ${x} ${y}`}
        stroke={plantStemColor}
        strokeWidth={5}
        fill="none"
        strokeLinecap="round"
      />
      {leafTiers}
      {weeds}
      {selected && (
        <circle cx={x} cy={SOIL_Y + 6} r={38} fill="none" stroke="var(--color-olive)" strokeWidth={1.5} strokeDasharray="3 4" />
      )}
      <g transform={`translate(${x} ${SOIL_Y + 74})`}>
        <rect x={-58} y={-16} width={116} height={44} rx={4} fill="var(--color-ivory-deep)" />
        <text y={0} textAnchor="middle" fontFamily="var(--font-mono)" fontSize={10} fill="var(--color-charcoal)">
          {moduleNameWords.slice(0, 2).map((word, index) => (
            <tspan key={`${word}-${index}`} x={0} dy={index === 0 ? 0 : 11}>
              {word}
            </tspan>
          ))}
        </text>
        <text y={20} textAnchor="middle" fontFamily="var(--font-mono)" fontSize={9} fill={visual.stemColor}>
          {health.level} · {health.healthScore}
        </text>
      </g>
    </g>
  );
}

export default function GardenCanvas({ garden, onPlantProject }: Props) {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [hasGrown, setHasGrown] = useState(false);

  useEffect(() => {
    if (!garden) {
      setHasGrown(false);
      return;
    }
    setHasGrown(false);
    const animationFrame = requestAnimationFrame(() => setHasGrown(true));
    return () => cancelAnimationFrame(animationFrame);
  }, [garden?.projectId]);

  const positions = useMemo(
    () => layoutModules(garden?.modules.map((m) => m.moduleId) ?? [], WIDTH, SOIL_Y),
    [garden]
  );
  const posById = useMemo(() => new Map(positions.map((p) => [p.moduleId, p])), [positions]);
  const middlePlantId = useMemo(
    () =>
      [...positions]
        .sort(
          (first, second) =>
            Math.abs(first.x - WIDTH / 2) - Math.abs(second.x - WIDTH / 2) || second.y - first.y
        )[0]?.moduleId,
    [positions]
  );

  const selected = garden?.modules.find((m) => m.moduleId === selectedId) ?? null;

  return (
    <div className="garden-canvas-shell" style={{ display: "flex", gap: 24, flexWrap: "wrap", alignItems: "flex-start" }}>
      <div className={`garden-canvas-stage${garden ? " garden-canvas-stage--populated" : ""}`}>
      <svg className="garden-canvas" viewBox={`0 0 ${WIDTH} ${HEIGHT}`} width="100%" role="img" aria-label="Codebase garden">
        <defs>
          <linearGradient id="garden-soil-gradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#4a3374" />
            <stop offset="32%" stopColor="#3c2a5e" />
            <stop offset="100%" stopColor="#1f1440" />
          </linearGradient>
          <linearGradient id="garden-sky-gradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#1a1038" />
            <stop offset="100%" stopColor="#150c29" />
          </linearGradient>
          <linearGradient id="garden-bug-coral" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ff8fc7" />
            <stop offset="58%" stopColor="#ff5c86" />
            <stop offset="100%" stopColor="#a02f56" />
          </linearGradient>
          <linearGradient id="garden-bug-gold" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#f9dfa0" />
            <stop offset="58%" stopColor="#f2c675" />
            <stop offset="100%" stopColor="#a97c33" />
          </linearGradient>
          <linearGradient id="garden-bug-moss" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#7fe8dd" />
            <stop offset="58%" stopColor="#3ddad0" />
            <stop offset="100%" stopColor="#1f8f8a" />
          </linearGradient>
          <linearGradient id="garden-bug-slate" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#c3adf0" />
            <stop offset="58%" stopColor="#9b7fd4" />
            <stop offset="100%" stopColor="#5a3d78" />
          </linearGradient>
        </defs>
        <rect x={0} y={0} width={WIDTH} height={HEIGHT} fill="url(#garden-sky-gradient)" />
        <rect x={0} y={SOIL_Y} width={WIDTH} height={HEIGHT - SOIL_Y} fill="url(#garden-soil-gradient)" />

        {/* Roots: dependency edges, illuminated (more visible) when either end is unhealthy */}
        <g style={{ opacity: hasGrown ? 1 : 0, transition: "opacity 700ms ease 350ms" }}>
        {garden?.edges.map((edge, i) => {
          const from = posById.get(edge.fromModuleId);
          const to = posById.get(edge.toModuleId);
          if (!from || !to) return null;
          const fromHealth = garden.modules.find((m) => m.moduleId === edge.fromModuleId);
          const toHealth = garden.modules.find((m) => m.moduleId === edge.toModuleId);
          const minHealth = Math.min(fromHealth?.healthScore ?? 100, toHealth?.healthScore ?? 100);
          const illuminated = minHealth < 55;
          const rootY = SOIL_Y + 10;
          const midY = Math.min(SOIL_Y + 56, rootY + 14 + Math.abs(from.x - to.x) * 0.04);
          const rootColor = illuminated ? "#ff8fc7" : "var(--color-root)";
          const rootWidth = illuminated ? 2.5 : 1.5;
          return (
            <g key={i} opacity={illuminated ? 0.75 : 0.35} fill="none" stroke={rootColor} strokeWidth={rootWidth} strokeLinecap="round">
              <path d={`M ${from.x} ${SOIL_Y} L ${from.x} ${rootY}`} />
              <path d={`M ${from.x} ${rootY} Q ${(from.x + to.x) / 2} ${midY} ${to.x} ${rootY}`} />
              <path d={`M ${to.x} ${rootY} L ${to.x} ${SOIL_Y}`} />
            </g>
          );
        })}
        </g>

        {garden?.modules.map((health) => {
          const pos = posById.get(health.moduleId);
          if (!pos) return null;
          return (
            <g key={health.moduleId} style={{ transformBox: "view-box", transformOrigin: `${pos.x}px ${SOIL_Y}px`, transform: hasGrown ? "scaleY(1)" : "scaleY(0)", transition: "transform 850ms cubic-bezier(0.2, 0.8, 0.2, 1)" }}>
            <Plant
              key={health.moduleId}
              x={pos.x}
              y={pos.y}
              health={health}
              selected={selectedId === health.moduleId}
              middlePlant={middlePlantId === health.moduleId}
              onSelect={() => setSelectedId(health.moduleId)}
            />
            </g>
          );
        })}
        {!garden && (
          <g>
            {EMPTY_GARDEN_BUGS.map((bug, index) => <GardenBug key={index} {...bug} />)}
            <ellipse cx={WIDTH / 2} cy={SOIL_Y + 18} rx={88} ry={12} fill="#6b4fa0" opacity={0.3} />
            <path d={`M ${WIDTH / 2 - 54} ${SOIL_Y - 80} L ${WIDTH / 2 + 54} ${SOIL_Y - 80} L ${WIDTH / 2 + 38} ${SOIL_Y + 4} L ${WIDTH / 2 - 38} ${SOIL_Y + 4} Z`} fill="#4a3374" stroke="var(--color-root)" strokeWidth={4} strokeLinejoin="round" />
            <ellipse cx={WIDTH / 2} cy={SOIL_Y - 80} rx={58} ry={13} fill="#5a3d78" stroke="var(--color-root)" strokeWidth={4} />
            <ellipse cx={WIDTH / 2} cy={SOIL_Y - 80} rx={45} ry={8} fill="#2a1c4d" />
            <path d={`M ${WIDTH / 2} ${SOIL_Y - 82} Q ${WIDTH / 2 - 4} ${SOIL_Y - 116} ${WIDTH / 2} ${SOIL_Y - 142}`} stroke="var(--color-forest)" strokeWidth={5} fill="none" strokeLinecap="round" />
            <ellipse cx={WIDTH / 2 - 14} cy={SOIL_Y - 123} rx={16} ry={8} fill="var(--color-sage)" transform={`rotate(-28 ${WIDTH / 2 - 14} ${SOIL_Y - 123})`} />
            <ellipse cx={WIDTH / 2 + 15} cy={SOIL_Y - 139} rx={16} ry={8} fill="var(--color-sage)" transform={`rotate(28 ${WIDTH / 2 + 15} ${SOIL_Y - 139})`} />
          </g>
        )}
      </svg>
      {!garden && onPlantProject && (
        <div className="garden-canvas__empty-panel">
          <h2>Your Garden is waiting for a project</h2>
          <p>Plant a ZIP, a project folder, or a public GitHub repository to grow this garden from real analysis.</p>
          <button onClick={onPlantProject}>Plant Your Project</button>
        </div>
      )}
      </div>

      {garden && <aside style={{ minWidth: 240, flex: 1 }}>
        <h3 style={{ fontSize: 18, marginBottom: 8 }}>
          {selected ? selected.moduleName : garden.projectName}
        </h3>
        {selected ? (
          <div>
            <p style={{ fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--color-olive)" }}>
              Health {selected.healthScore}/100 · {selected.level}
            </p>
            <ul style={{ paddingLeft: 18, margin: 0, fontSize: 14, lineHeight: 1.6 }}>
              {selected.reasons.map((r, i) => (
                <li key={i}>{r}</li>
              ))}
            </ul>
          </div>
        ) : (
          <p style={{ fontSize: 14, lineHeight: 1.6, color: "var(--color-muted-strong)" }}>
            Overall ecosystem health: <strong>{garden.overallHealth}/100</strong>.
            Click any plant to see why it looks the way it does — every color and weed here comes
            straight from live issue data.
          </p>
        )}
      </aside>}
    </div>
  );
}
